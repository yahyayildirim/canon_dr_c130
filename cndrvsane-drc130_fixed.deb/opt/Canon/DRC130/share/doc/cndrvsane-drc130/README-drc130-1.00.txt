=================================================================================
Canon Electronics Scanner Driver for Linux Version 1.00

PLEASE READ THIS DOCUMENT CAREFULLY
=================================================================================

---------------------------------------------------------------------------------
Trademarks
SANE


---------------------------------------------------------------------------------


---------------------------------------------------------------------------------
CONTENTS

Before Starting
1. Introduction
2. Distribution File Structure of the Canon Electronics Scanner Driver for Linux
3. Hardware Requirements
4. Cautions, Limitations, and Restrictions
---------------------------------------------------------------------------------


1. Introduction -----------------------------------------------------------------
Thank you for using the Canon Electronics Scanner Driver for Linux. This scannner 
driver provides scanning functions for Canon Electronics scanners operating under
the SANE (Scan Access Now Easy) environment, a scanning system that operates on 
Linux operating systems.


2. Distribution File Structure of the Canon Electronics Scanner Driver for Linux -----
The Canon Electronics Scanner Driver for Linux distribution files are as follows:
Furthermore, the file name for the SANE driver common module and scanner driver
module differs depending on the version.

- README-drc130-1.00.txt (This document)
Describes supplementary information on the Canon Electronics Scanner Driver for Linux.

- LICENSE-drc130-1.00x.txt
Describes User License Agreement on the Canon Electronics Scanner Driver for Linux.

- cndrvsane-drc130-1.00-X.i386.rpm (for 32-bit)
- cndrvsane-drc130_1.00-X_i386.deb (for Debian 32-bit)
Installation package for the Canon Electronics Scanner Driver for Linux.

3. Hardware Requirements --------------------------------------------------------
This Scanner driver can be used with the following hardware environment.

Hardware: Computer that is enable to operate Linux, with x86 compatible CPU
          (32-bit)

Suppoeted Scanner: DR-C130


4. Cautions, Limitations, and Restrictions -------------------------------------
This Scanner driver is tested on the following OS environment.

- Debian GNU Linux 6.0
- Debian GNU Linux 7.0
- Ubuntu 11.10 Desktop
- Ubuntu 12.04 Desktop
- Ubuntu 12.10 Desktop
- Ubuntu 13.04 Desktop
- Fedora 16
- Fedora 17
- Fedora 18
- Fedora 19
- SUSE Linux12.1(openSUSE)
- SUSE Linux12.2(openSUSE)
- SUSE Linux12.3(openSUSE)

At installing on Ubuntu Desktop with Ubuntu Software Center. the installation may fail.
So, please install this Scanner driver package via console UI.
        dpkg -i cndrvsane-drc130_1.00-X_i386.deb

After installing on SUSE Linux, please execute the follow settings to use as USER authority.
        1. Open "/etc/udev/rules.d/55-libsane.rules" as ROOT authority.
        2. Add or change lines as follows.
                # Canon DR-C130
                ATTR{idVendor}=="1083", ATTR{idProduct}=="164a", MODE="0666", GROUP="lp", ENV{libsane_matched}="yes"
        3. Restart system.

At scanning under [DEKSEW=checked] and [User Defined Size], the Top-Left
position of image is the Top-Left position of detected document regardless of
the setting of tl-x and tl-y;


=================================================================================
Support
=================================================================================
This Software and Related Information are independently developed by Canon and
distributed by Canon local company. Canon as manufacturer of printers supporting
the Software and Related Information ("Canon Printers"), and Canon local company
as selling agency of Canon Printers, do not receive any user support call and
/or request or any requests for information about the Software and Related
Information. Any demand for information about Canon Printers including
information about the repair and supplies for Canon Printers should be directed
to Canon local company.
=================================================================================
                                            Copyright CANON ELECTRONICS INC. 2014
